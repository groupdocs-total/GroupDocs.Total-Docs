## Merge DOCX files in Docker (GroupDocs.Merger for Python via .NET)

This sample merges `beginning.docx` and `appendix.docx` into `output/merged.docx` inside a Docker container.

### Build

```bash
docker build -t groupdocs-merger-net:basic-example .
```

### Run

```bash
docker run -it --rm -v ${PWD}/output:/app/output groupdocs-merger-net:basic-example
```

If you have a license file, place `GroupDocs.Total.lic` in the project root before building.

## Merge DOCX files in Docker (GroupDocs.Merger for .NET via Python)

This sample merges `main.docx` and `appendix.docx` into `output/merged.docx` inside a Docker container.

### Build

```bash
docker build -t groupdocs-merger-net:basic-example .
```

### Run

```bash
docker run -it --rm -v ${pwd}/output:/app/output groupdocs-merger-net:basic-example
```

If you have a license file, place `GroupDocs.Total.lic` in the project root before building.
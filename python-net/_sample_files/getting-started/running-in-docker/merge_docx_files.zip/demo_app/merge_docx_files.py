import os
from groupdocs.merger import License, Merger

def merge_docx_files():
    # Get license file absolute path
    license_path = os.path.abspath("./GroupDocs.Total.lic")

    if os.path.exists(license_path):
        # Create License and set the path
        license = License()
        license.set_license(license_path)

    # Ensure output directory exists
    os.makedirs("./output", exist_ok=True)

    # Initialize the merger
    with Merger("./beginning.docx") as merger:
        # Join the appendix to the beginning
        merger.join("./appendix.docx")
        # Save the merged document
        merger.save("./output/merged.docx")

if __name__ == "__main__":
    merge_docx_files()
﻿using System;
using System.IO;
using GroupDocs.Conversion;
using GroupDocs.Conversion.Options.Convert;

// Set the license (Optional)
string licensePath = Path.GetFullPath("./GroupDocs.Total.lic");
License license = new License();
license.SetLicense(licensePath);

// Initialize convert options and converter
PdfConvertOptions options = new PdfConvertOptions();
Converter converter = new Converter("./business-plan.docx");

// Convert and save file
converter.Convert("./output/business-plan.pdf", options);
